PJ Transportes - Aplicativo Web de Gestão de Viagens

Como usar:
1. Extraia o arquivo ZIP.
2. Abra o arquivo index.html no navegador.
3. Login de teste: admin / 1234.
4. Use o botão "Carregar exemplo" para ver dados parecidos com o PDF.

Funções incluídas:
- Tela de login com logomarca PJ Transportes.
- Painel com receita, despesa, lucro, margem, KM e consumo médio.
- Cadastro de viagens.
- Lançamento de despesas por viagem.
- Botão para abrir rota no Google Maps.
- Relatório PDF geral e PDF por viagem.
- Exportação CSV compatível com Excel.
- Cadastro de veículos e motoristas.
- Dados salvos no próprio navegador usando localStorage.

Observação:
Este é um aplicativo web local/estático. Para usar com várias pessoas ao mesmo tempo, será necessário evoluir para banco de dados online, login real e hospedagem.
